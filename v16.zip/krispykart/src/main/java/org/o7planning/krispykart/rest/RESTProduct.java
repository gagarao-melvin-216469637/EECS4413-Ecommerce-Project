package org.o7planning.krispykart.rest;

import java.sql.Blob;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.DatatypeConverter;

import org.hibernate.annotations.GenericGenerator;

import com.google.gson.Gson;

@Table(name="products")
@Entity
public class RESTProduct {
	@Id
	@Column(name="code")
	private String code;
	
	@Lob
	@Column(name="image")
    private byte[] image;
	
	@Column(name="name")
    private String name;
	
	@Column(name="price")
    private double price;
	
	@Temporal(TemporalType.DATE)
	@Column(name="Create_Date")
	private Date date;

    public RESTProduct() {
    }
    
    public RESTProduct(String code, byte[] image, String name, double price, Date date) {
		super();
		this.code = code;
		this.image = image;
		this.name = name;
		this.price = price;
		this.date = date;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = "" + code;
	}

	public String getImage() {
		return DatatypeConverter.printBase64Binary(image);
	}

	public void setImage(String image) {
		// convert to Byte[]
		this.image = DatatypeConverter.parseBase64Binary(image);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}


	@Override
	public String toString() {
		return "RESTProduct [id=" + code + ", image=" + image + ", name=" + name + ", price=" + price + ", date=" + date
				+ "]";
	}
	
//	@Override
//	public String toString() {
//		//return ObjToJson.json(this);
//		//return new Gson().toJson(this);
//	
//	}
    
}