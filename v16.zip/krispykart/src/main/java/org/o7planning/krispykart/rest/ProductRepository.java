package org.o7planning.krispykart.rest;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
  
public interface ProductRepository extends JpaRepository<RESTProduct, Integer> {
	@Query("select p from RESTProduct p where p.code = ?1")
    List<RESTProduct> findProductBycode(String code);
}