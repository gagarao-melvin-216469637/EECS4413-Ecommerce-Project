package org.o7planning.krispykart.rest;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class ProductService {
	@Autowired
    private ProductRepository repo;
     
    public List<RESTProduct> listAll() {
        return repo.findAll();
    }
     
    public void save(RESTProduct product) {
        repo.save(product);
    }
     
    public RESTProduct get(String code) {
    	// This is dicey....
        return repo.findProductBycode(code).get(0);
    }
    
    public void delete(String code) {
    	repo.delete(get(code));
    }
}
