package org.o7planning.krispykart.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.NoSuchElementException;

@RestController
public class ProductController {

	@Autowired
	private ProductService service;
	
	@GetMapping("/products")
	public List<RESTProduct> list() {
	    return service.listAll();
	}
	
	@GetMapping("/products/{code}")
	public ResponseEntity<RESTProduct> get(@PathVariable String code) {
	    try {
	    	RESTProduct product = service.get(code);
	        return new ResponseEntity<RESTProduct>(product, HttpStatus.OK);
	    } catch (NoSuchElementException e) {
	        return new ResponseEntity<RESTProduct>(HttpStatus.NOT_FOUND);
	    }      
	}
	
	// give arguments via the Body!
	@PostMapping("/products")
	public void add(@RequestBody RESTProduct product) {
	    service.save(product);
	}

	@PutMapping("/products/{code}")
	public ResponseEntity<?> update(@RequestBody RESTProduct product, @PathVariable String code) {
	    try {
	    	RESTProduct existProduct = service.get(code);
	        service.save(product);
	        return new ResponseEntity<>(HttpStatus.OK);
	    } catch (NoSuchElementException e) {
	        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	    }      
	}
	
	@DeleteMapping("/products/{code}")
	public void delete(@PathVariable String code) {
	    service.delete(code);
	}
}
