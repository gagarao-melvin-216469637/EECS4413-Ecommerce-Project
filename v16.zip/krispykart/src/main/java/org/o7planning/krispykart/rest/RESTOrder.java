package org.o7planning.krispykart.rest;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Table(name = "orders")
@Entity
public class RESTOrder {

	@Id
	@Column(name = "ID")
	private String id;

	@Column(name = "AMOUNT")
	private double amount;

	@Column(name = "CUSTOMER_ADDRESS")
	private String customer_address;

	@Column(name = "CUSTOMER_EMAIL")
	private String customer_email;

	@Column(name = "CUSTOMER_NAME")
	private String customer_name;

	@Column(name = "CUSTOMER_PHONE")
	private String customer_phone;

	@Temporal(TemporalType.DATE)
	@Column(name = "ORDER_DATE")
	private Date order_date;

	@Column(name = "ORDER_NUM")
	private int order_num;

	public RESTOrder() {
	}

	public RESTOrder(String id, double amount, String customer_address, String customer_email, String customer_name,
			String customer_phone, Date order_date, int order_num) {
		super();
		this.id = id;
		this.amount = amount;
		this.customer_address = customer_address;
		this.customer_email = customer_email;
		this.customer_name = customer_name;
		this.customer_phone = customer_phone;
		this.order_date = order_date;
		this.order_num = order_num;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getCustomer_address() {
		return customer_address;
	}

	public void setCustomer_address(String customer_address) {
		this.customer_address = customer_address;
	}

	public String getCustomer_email() {
		return customer_email;
	}

	public void setCustomer_email(String customer_email) {
		this.customer_email = customer_email;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public String getCustomer_phone() {
		return customer_phone;
	}

	public void setCustomer_phone(String customer_phone) {
		this.customer_phone = customer_phone;
	}

	public Date getOrder_date() {
		return order_date;
	}

	public void setOrder_date(Date order_date) {
		this.order_date = order_date;
	}

	public int getOrder_num() {
		return order_num;
	}

	public void setOrder_num(int order_num) {
		this.order_num = order_num;
	}

}
