package org.o7planning.krispykart.rest;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class OrderService {
	@Autowired
    private OrderRepository repo;
     
    public List<RESTOrder> listAll() {
        return repo.findAll();
    }
     
    public void save(RESTOrder order) {
        repo.save(order);
    }
     
    public RESTOrder get(String id) {
    	// This is dicey....
        return repo.findOrderByid(id).get(0);
    }
    
    public void delete(String id) {
    	repo.delete(get(id));
    }
}
