package org.o7planning.krispykart.sbshoppingcart;

import org.junit.jupiter.api.Test;
import org.o7planning.krispykart.KrispyKartApp;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes=KrispyKartApp.class)
class SbHibernateShoppingCartApplicationTests {

	@Test
	void contextLoads() {
	}

}
