package demo;

enum Status {

  IN_PROGRESS, //
  COMPLETED, //
  CANCELLED
}